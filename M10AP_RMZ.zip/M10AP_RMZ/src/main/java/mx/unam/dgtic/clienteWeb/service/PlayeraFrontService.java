package mx.unam.dgtic.clienteWeb.service;

import mx.unam.dgtic.model.Playera;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class PlayeraFrontService {
    @Autowired
    WebClient webClient;

    public List<Playera> getAll(){
        Mono<List<Playera>> playerasMono = webClient.get()
                .uri("/api/playera/listar-playeras")
                .retrieve()
                .bodyToFlux(Playera.class)
                .collectList();
        return playerasMono.block();
    }

    public Playera getPlayeraById(Integer id){
        Mono<Playera> playeraMono = webClient.get()
                .uri("/api/playera/{id}",id)
                .retrieve()
                .bodyToMono(Playera.class);
        return playeraMono.block();
    }

    public void actualizaPlayera(Playera playera) {
        webClient.put()
                .uri("/api/playera/{id}", playera.getIdPlayera())
                .bodyValue(playera)
                .retrieve()
                .bodyToMono(Playera.class)
                .block();
    }

    public Playera crearPlayera(Playera playera){
        return webClient.post()
                .uri("/api/playera/crear")
                .bodyValue(playera)
                .retrieve()
                .bodyToMono(Playera.class)
                .block();
    }




    public void deletePlayera(Integer idPlayera){
        webClient.delete()
                .uri("/api/playera/{id}",idPlayera)
                .retrieve()
                .toBodilessEntity()
                .block();
    }
    
}
