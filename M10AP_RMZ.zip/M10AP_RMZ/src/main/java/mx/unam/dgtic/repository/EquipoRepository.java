package mx.unam.dgtic.repository;

import mx.unam.dgtic.model.Equipo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EquipoRepository extends JpaRepository<Equipo,Integer> {
    Equipo findByNombre(String equipo);
}

