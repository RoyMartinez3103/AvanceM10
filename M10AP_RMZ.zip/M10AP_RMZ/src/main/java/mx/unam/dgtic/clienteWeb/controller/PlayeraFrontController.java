package mx.unam.dgtic.clienteWeb.controller;

import jakarta.validation.Valid;
import mx.unam.dgtic.clienteWeb.service.PlayeraFrontService;
import mx.unam.dgtic.model.Equipo;
import mx.unam.dgtic.model.Marca;
import mx.unam.dgtic.model.Playera;
import mx.unam.dgtic.service.equipo.EquipoServiceImpl;
import mx.unam.dgtic.service.marca.MarcaServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Este controlador se define para el front-end de una playera, contiene todas las vistas
 * que serán visibles dentro del navegador.
 *
 * @author Rodrigo Martínez Zambrano
 * @version 0.0.1
 */

@Controller
@RequestMapping("/playera")
public class PlayeraFrontController {
    
    @Autowired
    PlayeraFrontService playeraService;
    @Autowired
    MarcaServiceImpl marcaService;
    @Autowired
    EquipoServiceImpl equipoService;

    /**
     * El end-point mostrará una tabla con todas las playeras ys sus características.
     * @return String
     */

    @GetMapping(path = "/lista-playera")
    public String getAllPlayeras(Model model){
        model.addAttribute("playera",playeraService.getAll());
        return "/playera/lista-playera";
    }

    /**
     * El end-point muestra un formulario para ingresar los datos de una playera y
     * registrarla en el sistema.
     * @return String
     */

    @GetMapping("/alta-playera")
    public String altaPlayera(Model model){
        Playera playera = new Playera();
        List<Equipo> equipos = equipoService.getEquiposList();
        List<Marca> marcas = marcaService.getMarcasList();

        model.addAttribute("equipo",equipos);
        model.addAttribute("marca",marcas);
        model.addAttribute("playera",playera);
        model.addAttribute("contenido","Agregar nueva playera");
        return "/playera/alta-playera";
    }

    /**
     * El end-point realiza la acción de guardar la playera en el sistema.
     * @return String
     */

    @PostMapping("/salvar-playera")
    public String salvarPlayera(@Valid @ModelAttribute("playera") Playera playera,
                              BindingResult result,
                              Model model,
                              RedirectAttributes flash) {
        List<Equipo> equipos = equipoService.getEquiposList();
        List<Marca> marcas = marcaService.getMarcasList();

        model.addAttribute("equipo",equipos);
        model.addAttribute("marca",marcas);

        if (result.hasErrors()) {
            model.addAttribute("contenido", "ERROR. No debe ser vacío");
            return "/playera/alta-playera";
        }

        playeraService.crearPlayera(playera);
        System.out.println(playera);
        flash.addFlashAttribute("success", "La playera se guardó correctamente");

        return "redirect:/playera/lista-playera";
    }

    /**
     * El end-point realiza la acción de eliminar una playera existente.
     * @return String
     */

    @GetMapping("/eliminar-playera/{id}")
    public String eliminarPlayera(@PathVariable Integer id, RedirectAttributes flash) {
        try {
            playeraService.deletePlayera(id);
            flash.addFlashAttribute("success", "La playera se borró correctamente.");
        } catch (DataIntegrityViolationException e) {
            // Este error ocurre cuando hay violación de integridad referencial
            flash.addFlashAttribute("error",
                    "No se puede eliminar la playera.");
        } catch (Exception e) {
            // Para cualquier otro error inesperado
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/playera/lista-playera";
    }

    /**
     * El end-point muestra un formualrio para modificar información de una playera existente.
     * @return String
     */

    @GetMapping("/editar-playera/{id}")
    public String modificarPlayera(@PathVariable Integer id, Model model){
        Playera playera = playeraService.getPlayeraById(id);
        List<Equipo> equipos = equipoService.getEquiposList();
        List<Marca> marcas = marcaService.getMarcasList();

        model.addAttribute("equipo",equipos);
        model.addAttribute("marca",marcas);
        model.addAttribute("playera",playera);
        model.addAttribute("contenido","Modificar Playera");
        model.addAttribute("subtitulo","Formulario para modificar una playera existente.");
        return "/playera/alta-playera";
    }


    
}
