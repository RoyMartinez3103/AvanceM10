package mx.unam.dgtic.service.usuario;

import mx.unam.dgtic.dto.UsuarioDto;
import mx.unam.dgtic.model.Usuario;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

public interface UsuarioDtoService {
    List<UsuarioDto> getUsuariosList();
    UsuarioDto updateUsuario(UsuarioDto usuario) throws ParseException;
    UsuarioDto createUsuario(UsuarioDto usuario) throws ParseException;
    boolean deleteUsuario(Integer id);
    Optional<UsuarioDto> getUsuarioById(Integer id);
}
