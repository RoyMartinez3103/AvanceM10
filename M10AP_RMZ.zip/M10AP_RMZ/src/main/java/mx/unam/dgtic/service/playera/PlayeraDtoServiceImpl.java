package mx.unam.dgtic.service.playera;

import mx.unam.dgtic.dto.PlayeraDto;
import mx.unam.dgtic.exception.EquipoNotFoundException;
import mx.unam.dgtic.exception.MarcaNotFoundException;
import mx.unam.dgtic.model.Equipo;
import mx.unam.dgtic.model.Marca;
import mx.unam.dgtic.model.Playera;
import mx.unam.dgtic.repository.EquipoRepository;
import mx.unam.dgtic.repository.MarcaRepository;
import mx.unam.dgtic.repository.PlayeraRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PlayeraDtoServiceImpl implements PlayeraDtoService {
    @Autowired
    PlayeraRepository playeraRepository;
    @Autowired
    MarcaRepository marcaRepository;
    @Autowired
    EquipoRepository equipoRepository;
    @Autowired
    ModelMapper modelMapper;

    @Override
    public List<PlayeraDto> getPlayerasList() {
        List<Playera> playeras = playeraRepository.findAll();
        return playeras.stream().map(this::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public PlayeraDto updatePlayera(PlayeraDto playera) throws ParseException {
        Playera playeraUpdated = playeraRepository.save(this.toEntity(playera));
        return toDto(playeraUpdated);
    }

    @Override
    public PlayeraDto createPlayera(PlayeraDto playera) throws ParseException {
        Playera playeraGuardada = playeraRepository.save(this.toEntity(playera));
        return toDto(playeraGuardada);
    }

    @Override
    public boolean deletePlayera(Integer id) {
        Optional<Playera> playera = playeraRepository.findById(id);
        if (playera.isPresent()){
            playeraRepository.deleteById(id);
            return true;
        }else {
            return false;
        }
    }

    @Override
    public Optional<PlayeraDto> getPlayeraById(Integer id) {
        Optional<Playera> playera = playeraRepository.findById(id);
        if(playera.isPresent()){
            PlayeraDto playeraDto = toDto(playera.get());
            return Optional.of(playeraDto);
        }
        else {
            return Optional.empty();
        }
    }

    private PlayeraDto toDto(Playera playera){
        PlayeraDto playeraDto = modelMapper.map(playera, PlayeraDto.class);
        playeraDto.setMarca(playera.getMarca().getNombre()); //No se revisa si != null ya que es obligatoria.
        playeraDto.setEquipo(playera.getEquipo().getNombre());
        return playeraDto;
    }

    private Playera toEntity(PlayeraDto playeraDto) throws ParseException{
        Playera playera = modelMapper.map(playeraDto,Playera.class);
        if(playeraDto.getMarca() != null && !playeraDto.getMarca().isEmpty()){
            Marca marca = marcaRepository.findByNombre(playeraDto.getMarca());
            if(marca == null){
                throw new MarcaNotFoundException("La marca no existe");
            }else{
                playera.setMarca(marca);
            }
        }
        if(playeraDto.getEquipo() != null && !playeraDto.getEquipo().isEmpty()){
            Equipo equipo = equipoRepository.findByNombre(playeraDto.getEquipo());
            if(equipo==null){
                throw new EquipoNotFoundException("El equipo no existe");
            }else{
                playera.setEquipo(equipo);
            }
        }
        return playera;
    }
}
