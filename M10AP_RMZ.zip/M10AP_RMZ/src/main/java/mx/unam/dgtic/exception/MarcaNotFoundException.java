package mx.unam.dgtic.exception;

public class MarcaNotFoundException extends RuntimeException {
    public MarcaNotFoundException(String message) {
        super(message);
    }
}
