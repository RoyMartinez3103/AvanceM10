package mx.unam.dgtic.service.usuario;

import mx.unam.dgtic.model.Usuario;

import java.util.List;
import java.util.Optional;

public interface UsuarioService {
    List<Usuario> getUsuariosList();
    Usuario updateUsuario(Usuario usuario);
    Usuario createUsuario(Usuario usuario);
    boolean deleteUsuario(Integer id);
    Optional<Usuario> getUsuarioById(Integer id);
}
