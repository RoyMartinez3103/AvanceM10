package mx.unam.dgtic.controller.marca;

import mx.unam.dgtic.model.Marca;
import mx.unam.dgtic.service.marca.MarcaServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * Este controlador se define para el consumo de las API de una marca, produce un
 * formato JSON.
 *
 * @author Rodrigo Martínez Zambrano
 * @version 0.0.1
 */

@RestController
@RequestMapping("/api/marca")
public class MarcaController {

    @Autowired
    MarcaServiceImpl marcaService;

    /**
     * El end-point regresa la lista de todas las marcas existentes.
     * @return List
     */

    @GetMapping("/listar-marcas")
    public ResponseEntity<List<Marca>> getAll(){
        return ResponseEntity.ok(marcaService.getMarcasList());
    }

    /**
     * El end-point regresa la marca con un id específico.
     * @return Marca
     */
    
    @GetMapping("/{id}")
    public ResponseEntity<Marca> getMArcaById(@PathVariable Integer id){
        Optional<Marca> marca = marcaService.getMarcaById(id);
        if (marca.isPresent()) {
            return ResponseEntity.ok(marca.get());
        } else
            return ResponseEntity.notFound().build();
    }

    /**
     * El end-point elimina el registro con un id especifico.
     * @return Boolean
     */

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> deleteMarca(@PathVariable Integer id) {
        if(marcaService.deleteMarca(id)){
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * El end-point registra una nueva marca.
     * @return Marca
     */

    @PostMapping("/crear")
    public ResponseEntity<Marca> crearMarca(@RequestBody Marca marca) throws URISyntaxException {
        Marca marcaNueva = marcaService.createMarca(marca);
        URI location = new URI("/marca"+ marcaNueva.getIdMarca());
        return ResponseEntity.created(location).body(marcaNueva);
    }

    /**
     * El end-point modifica una marca existente o la crea si no existe.
     * @return Marca
     */

    @PutMapping("/{id}")
    public ResponseEntity<Marca> modificarMarca(@PathVariable Integer id, @RequestBody Marca marca) throws URISyntaxException {
        Optional<Marca> marcaBD = marcaService.getMarcaById(id);
        if(marcaBD.isPresent()){
            return ResponseEntity.ok(marcaService.updateMarca(marca));
        }else {
            Marca marcaNuevo = marcaService.createMarca(marca);
            URI location = new URI("/marca/"+ marcaNuevo.getIdMarca());
            return ResponseEntity.created(location).body(marcaNuevo);
        }
    }
}
