package mx.unam.dgtic.controller.usuario;

import mx.unam.dgtic.model.Usuario;
import mx.unam.dgtic.service.usuario.UsuarioServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * Este controlador se define para el consumo de las API de una playera, produce un
 * formato JSON.
 *
 * @author Rodrigo Martínez Zambrano
 * @version 0.0.1
 */

@RestController
@RequestMapping(value = "/api/usuario", produces = MediaType.APPLICATION_JSON_VALUE)
public class UsuarioController {

    @Autowired
    UsuarioServiceImpl usuarioService;

    /**
     * El end-point regresa la lista de todos los usuarios existentes.
     * @return List
     */

    @GetMapping("/listar-usuarios")
    public ResponseEntity<List<Usuario>> getAll(){
        return ResponseEntity.ok(usuarioService.getUsuariosList());
    }

    /**
     * El end-point regresa el usuario con un id específico.
     * @return Playera
     */

    @GetMapping("/{id}")
    public ResponseEntity<Usuario> getMarcaById(@PathVariable Integer id){
        Optional<Usuario> usuario = usuarioService.getUsuarioById(id);
        if (usuario.isPresent()) {
            return ResponseEntity.ok(usuario.get());
        } else
            return ResponseEntity.notFound().build();
    }

    /**
     * El end-point elimina el registro con un id específico.
     * @return Boolean
     */

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> deleteUsuario(@PathVariable Integer id) {
        if(usuarioService.deleteUsuario(id)){
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * El end-point registra una nueva playera.
     * @return Usuario
     */

    @PostMapping("/crear")
    public ResponseEntity<Usuario> crearUsuario(@RequestBody Usuario usuario) throws URISyntaxException {
        Usuario usuarioNuevo = usuarioService.createUsuario(usuario);
        URI location = new URI("/usuario"+ usuarioNuevo.getIdUsuario());
        return ResponseEntity.created(location).body(usuarioNuevo);
    }

    /**
     * El end-point modifica una playera existente o la crea si no existe.
     * @return Playera
     */

    @PutMapping("/{id}")
    public ResponseEntity<Usuario> modificarUsuario(@PathVariable Integer id, @RequestBody Usuario usuario) throws URISyntaxException {
        Optional<Usuario> usuarioBD = usuarioService.getUsuarioById(id);
        if(usuarioBD.isPresent()){
            return ResponseEntity.ok(usuarioService.updateUsuario(usuario));
        }else {
            Usuario usuarioNuevo = usuarioService.createUsuario(usuario);
            URI location = new URI("/usuario/"+ usuarioNuevo.getIdUsuario());
            return ResponseEntity.created(location).body(usuarioNuevo);
        }
    }
}

