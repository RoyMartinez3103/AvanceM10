package mx.unam.dgtic.controller.playera;

import mx.unam.dgtic.dto.PlayeraDto;
import mx.unam.dgtic.exception.EquipoNotFoundException;
import mx.unam.dgtic.exception.MarcaNotFoundException;
import mx.unam.dgtic.service.equipo.EquipoServiceImpl;
import mx.unam.dgtic.service.marca.MarcaServiceImpl;
import mx.unam.dgtic.service.playera.PlayeraDtoServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

/**
 * Este controlador se define para el consumo de las API de una Playera DTO, produce un
 * formato JSON.
 *
 * @author Rodrigo Martínez Zambrano
 * @version 0.0.1
 */

@RestController
@RequestMapping("/api/playeradto")
public class PlayeraDtoController {

    @Autowired
    PlayeraDtoServiceImpl playeraDtoService;

    /**
     * El end-point regresa la lista de todas las playeras existentes.
     * @return List
     */

    @GetMapping("/listar-playeras")
    public ResponseEntity<List<PlayeraDto>> getAll() {
        return ResponseEntity.ok(playeraDtoService.getPlayerasList());
    }

    /**
     * El end-point regresa la playera con un id específico.
     * @return Playera
     */

    @GetMapping("/{id}")
    public ResponseEntity<PlayeraDto> getPlayeraDtoById(@PathVariable Integer id) {
        Optional<PlayeraDto> playeraDto = playeraDtoService.getPlayeraById(id);
        if (playeraDto.isPresent()) {
            return ResponseEntity.ok(playeraDto.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * El end-point elimina el registro con un id específico.
     * @return Boolean
     */

    @DeleteMapping("/id")
    public ResponseEntity<Boolean> deletePlayeraDto(@PathVariable Integer id) {
        if (playeraDtoService.deletePlayera(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * El end-point registra una nueva playera.
     * @return Playera
     */

    @PostMapping("/crear")
    public ResponseEntity<PlayeraDto> crearPlayeraDto(@RequestBody PlayeraDto playeraDto) throws URISyntaxException, ParseException, MarcaNotFoundException, EquipoNotFoundException {
        PlayeraDto playeraDtoNueva = playeraDtoService.createPlayera(playeraDto);
        URI location = new URI("/playeraDto" + playeraDtoNueva.getIdPlayera());
        return ResponseEntity.created(location).body(playeraDtoNueva);
    }

    /**
     * El end-point modifica una playera existente o la crea si no existe.
     * @return Playera
     */

    @PutMapping("/{id}")
    public ResponseEntity<PlayeraDto> modificarPlayeraDto(@PathVariable Integer id, @RequestBody PlayeraDto playeraDto) throws URISyntaxException, ParseException {
        Optional<PlayeraDto> playeraDtoBD = playeraDtoService.getPlayeraById(id);
        if (playeraDtoBD.isPresent()) {
            return ResponseEntity.ok(playeraDtoService.updatePlayera(playeraDto));
        } else {
            PlayeraDto playeraDtoNueva = playeraDtoService.createPlayera(playeraDto);
            URI location = new URI("/playeraDto" + playeraDtoNueva.getIdPlayera());
            return ResponseEntity.created(location).body(playeraDtoNueva);
        }
    }

}