package mx.unam.dgtic.controller.playera;

import mx.unam.dgtic.model.Playera;
import mx.unam.dgtic.service.equipo.EquipoServiceImpl;
import mx.unam.dgtic.service.marca.MarcaServiceImpl;
import mx.unam.dgtic.service.playera.PlayeraServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

/**
 * Este controlador se define para el consumo de las API de una playera, produce un
 * formato JSON.
 *
 * @author Rodrigo Martínez Zambrano
 * @version 0.0.1
 */

@RestController
@RequestMapping("/api/playera")
public class PlayeraController {

    @Autowired
    PlayeraServiceImpl playeraService;

    /**
     * El end-point regresa la lista de todas las playeras existentes.
     * @return List
     */

    @GetMapping("/listar-playeras")
    public ResponseEntity<List<Playera>> getAll() {
        return ResponseEntity.ok(playeraService.getPlayerasList());
    }

    /**
     * El end-point regresa la playera con un id específico.
     * @return Playera
     */

    @GetMapping("/{id}")
    public ResponseEntity<Playera> getPlayeraById(@PathVariable Integer id) {
        Optional<Playera> playera = playeraService.getPlayeraById(id);
        if (playera.isPresent()) {
            return ResponseEntity.ok(playera.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * El end-point elimina el registro con un id específico.
     * @return Boolean
     */

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> deletePlayera(@PathVariable Integer id) {
        if (playeraService.deletePlayera(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * El end-point registra una nueva playera.
     * @return Playera
     */

    @PostMapping("/crear")
    public ResponseEntity<Playera> crearPlayera(@RequestBody Playera playera) throws URISyntaxException {
        Playera playeraNueva = playeraService.createPlayera(playera);
        URI location = new URI("/playera" + playeraNueva.getIdPlayera());
        return ResponseEntity.created(location).body(playeraNueva);
    }

    /**
     * El end-point modifica una playera existente o la crea si no existe.
     * @return Playera
     */

    @PutMapping("/{id}")
    public ResponseEntity<Playera> modificarPlayera(@PathVariable Integer id, @RequestBody Playera playera) throws URISyntaxException {
        Optional<Playera> playeraBD = playeraService.getPlayeraById(id);
        if (playeraBD.isPresent()) {
            return ResponseEntity.ok(playeraService.updatePlayera(playera));
        } else {
            Playera playeraNueva = playeraService.createPlayera(playera);
            URI location = new URI("/playera" + playeraNueva.getIdPlayera());
            return ResponseEntity.created(location).body(playeraNueva);
        }
    }

}