package mx.unam.dgtic.controller.equipo;

import mx.unam.dgtic.model.Equipo;
import mx.unam.dgtic.service.equipo.EquipoServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * Este controlador se define para el consumo de las API de un equipo, produce un
 * formato JSON.
 *
 * @author Rodrigo Martínez Zambrano
 * @version 0.0.1
 */

@RestController
@RequestMapping(path = "/api/equipo", produces = MediaType.APPLICATION_JSON_VALUE)
public class EquipoController {

    @Autowired
    EquipoServiceImpl equipoService;

    /**
     * El end-point regresa la lista de todos los equipos existentes.
     * @return List
     */

    @GetMapping("/listar-equipos")
    public ResponseEntity<List<Equipo>> getAll(){
        return  ResponseEntity.ok(equipoService.getEquiposList());
    }

    /**
     * El end-point regresa el equipo con un id específico.
     * @return Equipo
     */

    @GetMapping(path = "/{id}")
    public ResponseEntity<Equipo> getById(@PathVariable Integer id) {
        Optional<Equipo> equipo = equipoService.getEquipoById(id);
        if (equipo.isPresent()) {
            return ResponseEntity.ok(equipo.get());
        } else
            return ResponseEntity.notFound().build();
    }

    /**
     * El end-point elimina el registro con un id especifico.
     * @return Boolean
     */

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> deleteEquipo(@PathVariable Integer id){
        if(equipoService.deleteEquipo(id)){
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * El end-point crea un equipo.
     * @return Equipo
     */

    @PostMapping("/crear")
    public ResponseEntity<Equipo> createEquipo(@RequestBody Equipo equipo) throws URISyntaxException{
        Equipo equipoNuevo = equipoService.createEquipo(equipo);
        URI location = new URI("/equipo"+ equipoNuevo.getIdEquipo());
        return ResponseEntity.created(location).body(equipoNuevo);
    }

    /**
     * El end-point modifica un equipo existente o lo crea si no existe.
     * @return Equipo
     */

    @PutMapping("/{id}")
    public ResponseEntity<Equipo> modificarEquipo(@PathVariable Integer id, @RequestBody Equipo equipo) throws URISyntaxException{
        Optional<Equipo> equipoBD = equipoService.getEquipoById(id);
        if(equipoBD.isPresent()){
            return ResponseEntity.ok(equipoService.updateEquipo(equipo));
        }else {
            Equipo equipoNuevo = equipoService.createEquipo(equipo);
            URI location = new URI("/equipo/"+ equipoNuevo.getIdEquipo());
            return ResponseEntity.created(location).body(equipoNuevo);
        }
    }


}
