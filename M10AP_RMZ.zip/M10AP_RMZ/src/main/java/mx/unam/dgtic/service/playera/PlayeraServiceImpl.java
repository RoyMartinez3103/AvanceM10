package mx.unam.dgtic.service.playera;

import mx.unam.dgtic.exception.MarcaNotFoundException;
import mx.unam.dgtic.model.Playera;
import mx.unam.dgtic.repository.EquipoRepository;
import mx.unam.dgtic.repository.MarcaRepository;
import mx.unam.dgtic.repository.PlayeraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class PlayeraServiceImpl implements PlayeraService {

    @Autowired
    PlayeraRepository playeraRepository;
    @Autowired
    MarcaRepository marcaRepository;
    @Autowired
    EquipoRepository equipoRepository;


    @Override
    public List<Playera> getPlayerasList() {
        return playeraRepository.findAll();
    }

    @Override
    @Transactional
    public Playera updatePlayera(Playera playera) {
        if(!marcaRepository.existsById(playera.getMarca().getIdMarca())){
            throw new MarcaNotFoundException("La marca con ID: " + playera.getMarca().getIdMarca() + " no existe.");
        }
        if(!equipoRepository.existsById(playera.getEquipo().getIdEquipo())){
            throw new MarcaNotFoundException("El equipo con ID: " + playera.getEquipo().getIdEquipo() + " no existe.");
        }
        return playeraRepository.save(playera);
    }

    @Override
    @Transactional
    public Playera createPlayera(Playera playera) {
        if(!marcaRepository.existsById(playera.getMarca().getIdMarca())){
            throw new MarcaNotFoundException("La marca con ID: " + playera.getMarca().getIdMarca() + " no existe.");
        }
        if(!equipoRepository.existsById(playera.getEquipo().getIdEquipo())){
            throw new MarcaNotFoundException("El equipo con ID: " + playera.getEquipo().getIdEquipo() + " no existe.");
        }
        return playeraRepository.save(playera);
    }

    @Override
    @Transactional
    public boolean deletePlayera(Integer id) {
        Optional<Playera> playera = playeraRepository.findById(id);
        if (playera.isPresent()){
            playeraRepository.deleteById(id);
            return true;
        }else {
            return false;
        }
    }

    @Override
    public Optional<Playera> getPlayeraById(Integer id) {
        return playeraRepository.findById(id);
    }
}
