package mx.unam.dgtic.exception;

public class EquipoNotFoundException extends RuntimeException {
    public EquipoNotFoundException(String message) {
        super(message);
    }
}
