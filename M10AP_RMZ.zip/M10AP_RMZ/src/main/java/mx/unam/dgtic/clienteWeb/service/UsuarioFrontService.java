package mx.unam.dgtic.clienteWeb.service;

import mx.unam.dgtic.dto.UsuarioDto;
import mx.unam.dgtic.model.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class UsuarioFrontService {
    @Autowired
    WebClient webClient;

    public List<Usuario> getAll(){
        Mono<List<Usuario>> usuariosMono = webClient.get()
                .uri("/api/usuario/listar-usuarios")
                .retrieve()
                .bodyToFlux(Usuario.class)
                .collectList();
        return usuariosMono.block();
    }

    public Usuario getUsuarioById(Integer id){
        Mono<Usuario> usuarioMono = webClient.get()
                .uri("/api/usuario/{id}",id)
                .retrieve()
                .bodyToMono(Usuario.class);
        return usuarioMono.block();
    }

    public void actualizaUsuario(Usuario usuario) {
        webClient.put()
                .uri("/api/usuario/{id}", usuario.getIdUsuario())
                .bodyValue(usuario)
                .retrieve()
                .bodyToMono(Usuario.class)
                .block();
    }

    public Usuario crearUsuario(Usuario usuario){
        return webClient.post()
                .uri("/api/usuario/crear")
                .bodyValue(usuario)
                .retrieve()
                .bodyToMono(Usuario.class)
                .block();
    }




    public void deleteUsuario(Integer idUsuario){
        webClient.delete()
                .uri("/api/usuario/{id}",idUsuario)
                .retrieve()
                .toBodilessEntity()
                .block();
    }
}
