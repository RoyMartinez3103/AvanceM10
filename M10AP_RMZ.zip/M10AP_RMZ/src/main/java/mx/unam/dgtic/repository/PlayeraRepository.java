package mx.unam.dgtic.repository;

import mx.unam.dgtic.model.Playera;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlayeraRepository extends JpaRepository<Playera,Integer>{}
