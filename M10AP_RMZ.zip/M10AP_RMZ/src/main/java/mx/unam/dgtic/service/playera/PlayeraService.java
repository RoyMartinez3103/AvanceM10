package mx.unam.dgtic.service.playera;

import mx.unam.dgtic.model.Playera;

import java.util.List;
import java.util.Optional;

public interface PlayeraService {
    List<Playera> getPlayerasList();
    Playera updatePlayera(Playera playera);
    Playera createPlayera(Playera playera);
    boolean deletePlayera(Integer id);
    Optional<Playera> getPlayeraById(Integer id);
}
