package mx.unam.dgtic.clienteWeb.service;

import mx.unam.dgtic.model.Marca;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class MarcaFrontService {
    @Autowired
    WebClient webClient;
    
    public List<Marca> getAll(){
        Mono<List<Marca>> marcasMono = webClient.get()
                .uri("/api/marca/listar-marcas")
                .retrieve()
                .bodyToFlux(Marca.class)
                .collectList();
        return marcasMono.block();
    }

    public Marca getMarcaById(Integer id){
        Mono<Marca> marcaMono = webClient.get()
                .uri("/api/marca/{id}",id)
                .retrieve()
                .bodyToMono(Marca.class);
        return marcaMono.block();
    }

    public Marca actualizaMarca(Marca marca){
        return webClient.put()
                .uri("/api/marca/{id}",marca.getIdMarca())
                .bodyValue(marca)
                .retrieve()
                .bodyToMono(Marca.class)
                .block();
    }

    public Marca crearMarca(Marca marca){
        return webClient.post()
                .uri("/api/marca/crear")
                .bodyValue(marca)
                .retrieve()
                .bodyToMono(Marca.class)
                .block();
    }

    public void deleteMarca(Integer idMarca){
        webClient.delete()
                .uri("/api/marca/{id}",idMarca)
                .retrieve()
                .toBodilessEntity()
                .block();
    }
    
}
