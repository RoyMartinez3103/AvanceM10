package mx.unam.dgtic.service.marca;

import mx.unam.dgtic.model.Marca;
import mx.unam.dgtic.model.Marca;
import mx.unam.dgtic.repository.MarcaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class MarcaServiceImpl implements MarcaService{

    @Autowired
    MarcaRepository marcaRepository;


    @Override
    public List<Marca> getMarcasList() {
        return marcaRepository.findAll();
    }

    @Override
    @Transactional
    public Marca updateMarca(Marca marca) {
        return marcaRepository.save(marca);
    }

    @Override
    @Transactional
    public Marca createMarca(Marca marca) {
        return  marcaRepository.save(marca);
    }

    @Override
    @Transactional
    public boolean deleteMarca(Integer id) {
        Optional<Marca> marca = marcaRepository.findById(id);
        if (marca.isPresent()){
            marcaRepository.deleteById(id);
            return true;
        }else {
            return false;
        }
    }

    @Override
    public Optional<Marca> getMarcaById(Integer id) {
        return marcaRepository.findById(id);
    }
}
