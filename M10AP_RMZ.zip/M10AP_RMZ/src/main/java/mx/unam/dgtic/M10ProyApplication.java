package mx.unam.dgtic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M10ProyApplication {

	public static void main(String[] args) {
		SpringApplication.run(M10ProyApplication.class, args);
	}

}
