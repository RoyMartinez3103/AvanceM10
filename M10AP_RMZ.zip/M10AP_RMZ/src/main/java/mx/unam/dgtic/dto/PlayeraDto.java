package mx.unam.dgtic.dto;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import mx.unam.dgtic.model.Equipo;
import mx.unam.dgtic.model.Marca;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
@Data
public class PlayeraDto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_playera")
    private Integer idPlayera;

    private String color;
    @Pattern(regexp = "CH|M|G|XG", message = "La talla debe ser CH, M, G o XG")
    private String talla;

    @Column(name = "tipo_manga")
    private String tipoManga;

    @Digits(integer = 4,fraction = 2,message = "Valor incorrecto, se esparaba [4].[2] dígitos.")
    @DecimalMin(value = "0.0",inclusive = false)
    @Column(name = "precio_venta")
    private BigDecimal precioVenta;

    private String marca;

    private String equipo;

    public PlayeraDto() {
    }

    public PlayeraDto(String color, String talla, String tipoManga, BigDecimal precioReal, Integer stock, BigDecimal precioVenta, String marca, String equipo) {
        this.color = color;
        this.talla = talla;
        this.tipoManga = tipoManga;
        this.precioVenta = precioVenta;
        this.marca = marca;
        this.equipo = equipo;
    }


}
