package mx.unam.dgtic.clienteWeb.service;

import mx.unam.dgtic.model.Equipo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class EquipoFrontService {


    @Autowired
    WebClient webClient;

    public List<Equipo> getAll(){
        Mono<List<Equipo>> equiposMono = webClient.get()
                .uri("api/equipo/listar-equipos")
                .retrieve()
                .bodyToFlux(Equipo.class)
                .collectList();
        return equiposMono.block();
    }

    public Equipo getEquipoById(Integer id){
        Mono<Equipo> equipoMono = webClient.get()
                .uri("api/equipo/{id}",id)
                .retrieve()
                .bodyToMono(Equipo.class);
        return equipoMono.block();
    }

    public Equipo actualizaEquipo(Equipo equipo){
        return webClient.put()
                .uri("/api/equipo/{id}",equipo.getIdEquipo())
                .bodyValue(equipo)
                .retrieve()
                .bodyToMono(Equipo.class)
                .block();
    }

    public Equipo crearEquipo(Equipo equipo){
        return webClient.post()
                .uri("/api/equipo/crear")
                .bodyValue(equipo)
                .retrieve()
                .bodyToMono(Equipo.class)
                .block();
    }

    public void deleteEquipo(Integer idEquipo){
        webClient.delete()
                .uri("/api/equipo/{id}",idEquipo)
                .retrieve()
                .toBodilessEntity()
                .block();
    }

}
