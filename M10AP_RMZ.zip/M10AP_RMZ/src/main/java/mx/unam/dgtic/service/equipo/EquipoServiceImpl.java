package mx.unam.dgtic.service.equipo;

import mx.unam.dgtic.model.Equipo;
import mx.unam.dgtic.repository.EquipoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EquipoServiceImpl implements EquipoService{

    @Autowired
    EquipoRepository equipoRepository;


    @Override
    public List<Equipo> getEquiposList() {
        return equipoRepository.findAll();
    }

    @Override
    public Equipo updateEquipo(Equipo equipo) {
        return equipoRepository.save(equipo);
    }

    @Override
    public Equipo createEquipo(Equipo equipo) {
        return equipoRepository.save(equipo);
    }

    @Override
    public boolean deleteEquipo(Integer id) {
        Optional<Equipo> equipo = equipoRepository.findById(id);
        if (equipo.isPresent()){
            equipoRepository.deleteById(id);
            return true;
        }else {
            return false;
        }
    }

    @Override
    public Optional<Equipo> getEquipoById(Integer id) {
        return equipoRepository.findById(id);
    }
}
