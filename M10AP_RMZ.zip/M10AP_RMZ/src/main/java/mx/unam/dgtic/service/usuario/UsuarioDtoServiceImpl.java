package mx.unam.dgtic.service.usuario;

import mx.unam.dgtic.dto.UsuarioDto;
import mx.unam.dgtic.model.Usuario;
import mx.unam.dgtic.repository.UsuarioRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UsuarioDtoServiceImpl implements UsuarioDtoService {

    @Autowired
    UsuarioRepository usuarioRepository;
    @Autowired
    ModelMapper modelMapper;

    @Override
    public List<UsuarioDto> getUsuariosList() {
        List<Usuario> usuarios = usuarioRepository.findAll();
        return usuarios.stream().map(this::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public UsuarioDto updateUsuario(UsuarioDto usuario) throws ParseException {
        Usuario usuarioUpdated = usuarioRepository.save(this.toEntity(usuario));
        return toDto(usuarioUpdated);
    }

    @Override
    public UsuarioDto createUsuario(UsuarioDto usuario) throws ParseException {
        Usuario usuarioGuardado = usuarioRepository.save(this.toEntity(usuario));
        return toDto(usuarioGuardado);

    }

    @Override
    public boolean deleteUsuario(Integer id) {
        Optional<Usuario> usuario = usuarioRepository.findById(id);
        if (usuario.isPresent()){
            usuarioRepository.deleteById(id);
            return true;
        }else {
            return false;
        }
    }

    @Override
    public Optional<UsuarioDto> getUsuarioById(Integer id) {
        Optional<Usuario> usuario = usuarioRepository.findById(id);
        if(usuario.isPresent()){
            UsuarioDto usuarioDto = toDto(usuario.get());
            return Optional.of(usuarioDto);
        }
        else {
            return Optional.empty();
        }
    }

    private UsuarioDto toDto(Usuario usuario){
        return modelMapper.map(usuario, UsuarioDto.class);
    }

    private Usuario toEntity(UsuarioDto usuarioDto) throws ParseException{
        return modelMapper.map(usuarioDto,Usuario.class);
    }
}

