package mx.unam.dgtic.clienteWeb.controller;

import jakarta.validation.Valid;
import mx.unam.dgtic.clienteWeb.service.EquipoFrontService;
import mx.unam.dgtic.model.Equipo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Este controlador se define para el front end del sistema.
 *
 * @author Rodrigo Martínez Zambrano
 * @version 0.0.1
 */

@Controller
@RequestMapping("/equipo")
public class EquipoFrontController {
    @Autowired
    EquipoFrontService equipoService;

    /**
     * El end-point regresa en un tabla la lista de todos los equipos existentes.
     */

    @GetMapping(path = "/lista-equipo") //http://localhost:8080/equipo/lista-equipo -> url navegador
    public String getAllEquipos(Model model){
        model.addAttribute("equipo",equipoService.getAll());
        return "/equipo/lista-equipo"; //se retorna el html
    }

    /**
     * El end-point obtiene el formulario para editar un equipo existente.
     */

    @GetMapping("/editar-equipo/{id}")
    public String modificarEquipo(@PathVariable Integer id, Model model){
        Equipo equipo = equipoService.getEquipoById(id);
        model.addAttribute("equipo",equipo);
        model.addAttribute("contenido","Modificar Equipo");
        model.addAttribute("subtitulo","Formulario para modificar un equipo existente.");
        return "/equipo/alta-equipo";
    }

    /**
     * El end-point obtiene el formulario para agregar un equipo.
     */
    @GetMapping(path = "/alta-equipo")
    public String getFormAlta(Model model){
        Equipo equipo = new Equipo();
        model.addAttribute("contenido","Agregar nuevo equipo");
        model.addAttribute("equipo",equipo);
        return "/equipo/alta-equipo";
    }


    /**
     * El end-point se encarga de guardar el nuevo equipo.
     */

    @PostMapping("/salvar-equipo")
    public String salvarEquipo(@Valid @ModelAttribute("equipo") Equipo equipo,
                               BindingResult result,
                               Model model,
                               RedirectAttributes flash){
        if(result.hasErrors()){
            model.addAttribute("contenido","ERROR");
            return "/equipo/alta-equipo";
        }

        equipoService.crearEquipo(equipo);
        System.out.println(equipo);
        flash.addFlashAttribute("success", "El equipo se guardó correctamente");

        return "redirect:/equipo/lista-equipo";
    }

    @GetMapping("/eliminar-equipo/{id}")
    public String eliminarEquipo(@PathVariable Integer id, RedirectAttributes flash) {
        try {
            equipoService.deleteEquipo(id);
            flash.addFlashAttribute("success", "El equipo se borró correctamente.");
        } catch (DataIntegrityViolationException e) {
            // Este error ocurre cuando hay violación de integridad referencial
            flash.addFlashAttribute("error",
                    "No se puede eliminar el equipo porque está registrado en una playera.");
        } catch (Exception e) {
            // Para cualquier otro error inesperado
            flash.addFlashAttribute("error", "Ocurrió un error al intentar eliminar el equipo.");
        }
        return "redirect:/equipo/lista-equipo";
    }



}
