package mx.unam.dgtic.service.playera;

import mx.unam.dgtic.dto.PlayeraDto;
import mx.unam.dgtic.model.Playera;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

public interface PlayeraDtoService {
    List<PlayeraDto> getPlayerasList();
    PlayeraDto updatePlayera(PlayeraDto playera) throws ParseException;
    PlayeraDto createPlayera(PlayeraDto playera) throws ParseException;
    boolean deletePlayera(Integer id);
    Optional<PlayeraDto> getPlayeraById(Integer id);
}
