package mx.unam.dgtic.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;

@RestControllerAdvice
public class ManejadorGlobalExcepciones {
    @ExceptionHandler(MarcaNotFoundException.class)
    public ResponseEntity<DetalleError> errorDeRestriccion(MarcaNotFoundException e, HttpServletRequest request){
        DetalleError detalleError = new DetalleError();
        detalleError.setMensaje(e.getMessage());
        detalleError.setStatusCode(HttpStatus.CONFLICT.toString());
        detalleError.setTimestamp(LocalDateTime.now());
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .contentType(MediaType.APPLICATION_JSON)
                .body(detalleError);
    }
}
