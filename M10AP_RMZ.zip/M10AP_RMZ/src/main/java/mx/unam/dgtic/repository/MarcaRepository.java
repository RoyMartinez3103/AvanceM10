package mx.unam.dgtic.repository;

import mx.unam.dgtic.model.Marca;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MarcaRepository extends JpaRepository<Marca,Integer>{
    Marca findByNombre(String marca);
}
