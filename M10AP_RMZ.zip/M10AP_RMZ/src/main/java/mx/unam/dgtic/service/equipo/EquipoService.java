package mx.unam.dgtic.service.equipo;

import mx.unam.dgtic.model.Equipo;
import java.util.List;
import java.util.Optional;

public interface EquipoService {
    List<Equipo> getEquiposList();
    Equipo updateEquipo(Equipo equipo);
    Equipo createEquipo(Equipo equipo);
    boolean deleteEquipo(Integer id);
    Optional<Equipo> getEquipoById(Integer id);
}
