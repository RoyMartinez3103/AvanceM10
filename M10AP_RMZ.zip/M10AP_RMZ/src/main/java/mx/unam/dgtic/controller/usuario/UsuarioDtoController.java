package mx.unam.dgtic.controller.usuario;

import mx.unam.dgtic.dto.UsuarioDto;
import mx.unam.dgtic.model.Usuario;
import mx.unam.dgtic.service.usuario.UsuarioDtoService;
import mx.unam.dgtic.service.usuario.UsuarioServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/usuariodto/")
public class UsuarioDtoController {

    @Autowired
    UsuarioDtoService usuarioDtoService;

    @GetMapping("/listar-usuarios")
    public ResponseEntity<List<UsuarioDto>> getAll(){
        return ResponseEntity.ok(usuarioDtoService.getUsuariosList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UsuarioDto> getMArcaById(@PathVariable Integer id){
        Optional<UsuarioDto> usuario = usuarioDtoService.getUsuarioById(id);
        if (usuario.isPresent()) {
            return ResponseEntity.ok(usuario.get());
        } else
            return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> deleteUsuario(@PathVariable Integer id) {
        if(usuarioDtoService.deleteUsuario(id)){
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/crear")
    public ResponseEntity<UsuarioDto> crearUsuario(@RequestBody UsuarioDto usuario) throws URISyntaxException, ParseException {
        UsuarioDto usuarioNuevo = usuarioDtoService.createUsuario(usuario);
        URI location = new URI("/usuariodto"+ usuarioNuevo.getIdUsuario());
        return ResponseEntity.created(location).body(usuarioNuevo);
    }


    @PutMapping("/{id}")
    public ResponseEntity<UsuarioDto> modificarUsuario(@PathVariable Integer id, @RequestBody UsuarioDto usuario) throws URISyntaxException, ParseException {
        Optional<UsuarioDto> usuarioBD = usuarioDtoService.getUsuarioById(id);
        if(usuarioBD.isPresent()){
            return ResponseEntity.ok(usuarioDtoService.updateUsuario(usuario));
        }else {
            UsuarioDto usuarioNuevo = usuarioDtoService.createUsuario(usuario);
            URI location = new URI("/usuariodto/"+ usuarioNuevo.getIdUsuario());
            return ResponseEntity.created(location).body(usuarioNuevo);
        }
    }
}

