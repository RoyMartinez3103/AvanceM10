package mx.unam.dgtic.dto;

import jakarta.persistence.*;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
@Data
public class UsuarioDto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private Integer idUsuario;
    @Pattern(regexp = "^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$", message = "Solo se permiten letras, incluyendo acentos y ñ")
    private String nombre;
    @Pattern(regexp = "^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$", message = "Solo se permiten letras, incluyendo acentos y ñ")
    @Column(name = "apellido_pat")
    private String apellidoPat;
    @Pattern(regexp = "^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$", message = "Solo se permiten letras, incluyendo acentos y ñ")
    @Column(name = "apellido_mat")
    private String apellidoMat;
    @Past(message = "La fecha de nacimiento debe estar en el pasado")
    @Column(name = "fecha_nac")
    private LocalDate fechaNac;

    private String username;

    @Column(name = "ventas_realizadas")
    private Integer ventasRealizadas=0;

    public UsuarioDto() {
    }

    public UsuarioDto(Integer idUsuario, String nombre, String apellidoPat, String apellidoMat, LocalDate fechaNac, String username, Integer ventasRealizadas) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.apellidoPat = apellidoPat;
        this.apellidoMat = apellidoMat;
        this.fechaNac = fechaNac;
        this.username = username;
        this.ventasRealizadas = ventasRealizadas;
    }

    @Override
    public String toString() {
        return "UsuarioDto{" +
                "idUsuario=" + idUsuario +
                ", nombre='" + nombre + '\'' +
                ", apellidoPat='" + apellidoPat + '\'' +
                ", apellidoMat='" + apellidoMat + '\'' +
                ", fechaNac=" + fechaNac +
                ", username='" + username + '\'' +
                ", ventasRealizadas=" + ventasRealizadas +
                '}';
    }
}

