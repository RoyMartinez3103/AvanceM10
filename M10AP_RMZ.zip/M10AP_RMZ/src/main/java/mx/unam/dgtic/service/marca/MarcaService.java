package mx.unam.dgtic.service.marca;

import mx.unam.dgtic.model.Marca;

import java.util.List;
import java.util.Optional;

public interface MarcaService {
    List<Marca> getMarcasList();
    Marca updateMarca(Marca marca);
    Marca createMarca(Marca marca);
    boolean deleteMarca(Integer id);
    Optional<Marca> getMarcaById(Integer id);
}
