package mx.unam.dgtic.exception;

import java.time.LocalDateTime;

public class DetalleError {
    private String statusCode;
    private String mensaje;
    private LocalDateTime timestamp;

    public DetalleError(String statusCode, String mensaje, LocalDateTime timestamp) {
        this.statusCode = statusCode;
        this.mensaje = mensaje;
        this.timestamp = timestamp;
    }

    public DetalleError() {
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }


    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
