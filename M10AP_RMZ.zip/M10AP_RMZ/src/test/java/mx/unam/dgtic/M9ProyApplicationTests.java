package mx.unam.dgtic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M9ProyApplicationTests {

	@Test
	void contextLoads() {
	}

}
